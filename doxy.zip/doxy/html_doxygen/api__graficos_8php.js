var api__graficos_8php =
[
    [ "$sqlTotalLocais", "api__graficos_8php.html#ada9a71d228ea506514e2376fbc152330", null ],
    [ "try", "api__graficos_8php.html#a7bc13e3f1faf79eb1a30fe94cd0055c2", null ]
];