var admin__categorias_8php =
[
    [ "$categorias", "admin__categorias_8php.html#a4a1ae44f0e8e6dcbb0723eb952ef4431", null ],
    [ "$msg", "admin__categorias_8php.html#a9e168f4152c267835864153c54449583", null ],
    [ "$stmt", "admin__categorias_8php.html#af27a9140d5f2658693e7fd107f716449", null ]
];