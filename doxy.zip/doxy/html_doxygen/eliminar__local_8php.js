var eliminar__local_8php =
[
    [ "$id", "eliminar__local_8php.html#a08a00586f6759822a046f42a83e5c690", null ],
    [ "$stmt", "eliminar__local_8php.html#af27a9140d5f2658693e7fd107f716449", null ],
    [ "try", "eliminar__local_8php.html#ae434af2af59971ef6836f13a821a6d41", null ]
];