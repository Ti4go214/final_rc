var files_dup =
[
    [ "admin_categorias.php", "admin__categorias_8php.html", "admin__categorias_8php" ],
    [ "admin_dashboard_graficos.php", "admin__dashboard__graficos_8php.html", "admin__dashboard__graficos_8php" ],
    [ "admin_utilizadores.php", "admin__utilizadores_8php.html", "admin__utilizadores_8php" ],
    [ "api_graficos.php", "api__graficos_8php.html", "api__graficos_8php" ],
    [ "api_locais.php", "api__locais_8php.html", "api__locais_8php" ],
    [ "avaliar_local.php", "avaliar__local_8php.html", null ],
    [ "config_email.php", "config__email_8php.html", null ],
    [ "db.php", "db_8php.html", null ],
    [ "eliminar_local.php", "eliminar__local_8php.html", "eliminar__local_8php" ],
    [ "enviar_email.php", "enviar__email_8php.html", "enviar__email_8php" ],
    [ "index.php", "index_8php.html", "index_8php" ],
    [ "inserir_local.php", "inserir__local_8php.html", "inserir__local_8php" ],
    [ "locais_lista.php", "locais__lista_8php.html", "locais__lista_8php" ],
    [ "login.php", "login_8php.html", "login_8php" ],
    [ "logout.php", "logout_8php.html", null ],
    [ "registar.php", "registar_8php.html", "registar_8php" ]
];