var enviar__email_8php =
[
    [ "$emailDest", "enviar__email_8php.html#abfb06d761cc989643999ad2191258118", null ],
    [ "$nomeLocal", "enviar__email_8php.html#a2bef870ba72511a78fac9ec94c1efa29", null ],
    [ "if", "enviar__email_8php.html#a4a4d52370cb11e102017e83d799a23b5", null ],
    [ "SMTPOptions", "enviar__email_8php.html#a7f443129df384681fe7089e04e04b313", null ]
];