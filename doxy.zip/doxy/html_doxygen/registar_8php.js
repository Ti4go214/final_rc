var registar_8php =
[
    [ "$sucesso", "registar_8php.html#a753c4666a955220ce7a5cb04ef8a2031", null ]
];