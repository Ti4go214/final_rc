var searchData=
[
  ['config_5femail_2ephp_0',['config_email.php',['../config__email_8php.html',1,'']]]
];
