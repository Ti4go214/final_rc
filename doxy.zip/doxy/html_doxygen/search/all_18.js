var searchData=
[
  ['🛠️_20gestão_20e_20administração_20crud_0',['🛠️ Gestão e Administração (CRUD)',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['🛠️_20tecnologias_20utilizadas_1',['🛠️ Tecnologias Utilizadas',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]]
];
