var searchData=
[
  ['para_20executar_20localmente_0',['💻 Instruções para Executar Localmente',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['passos_20de_20instalação_1',['Passos de Instalação',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['pesquisa_20e_20filtros_2',['🔍 Pesquisa e Filtros',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['pré_20requisitos_3',['Pré-requisitos',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]],
  ['principais_4',['🚀 Funcionalidades Principais',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['projeto_5',['📝 Descrição do Projeto',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
