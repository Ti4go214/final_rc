var searchData=
[
  ['locais_5flista_2ephp_0',['locais_lista.php',['../locais__lista_8php.html',1,'']]],
  ['localmente_1',['💻 Instruções para Executar Localmente',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['login_2ephp_2',['login.php',['../login_8php.html',1,'']]],
  ['logout_2ephp_3',['logout.php',['../logout_8php.html',1,'']]]
];
