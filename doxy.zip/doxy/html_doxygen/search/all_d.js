var searchData=
[
  ['tecnologias_20utilizadas_0',['🛠️ Tecnologias Utilizadas',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['try_1',['try',['../api__graficos_8php.html#a7bc13e3f1faf79eb1a30fe94cd0055c2',1,'try:&#160;api_graficos.php'],['../eliminar__local_8php.html#ae434af2af59971ef6836f13a821a6d41',1,'try:&#160;eliminar_local.php']]]
];
