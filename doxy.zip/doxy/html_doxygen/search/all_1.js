var searchData=
[
  ['admin_5fcategorias_2ephp_0',['admin_categorias.php',['../admin__categorias_8php.html',1,'']]],
  ['admin_5fdashboard_5fgraficos_2ephp_1',['admin_dashboard_graficos.php',['../admin__dashboard__graficos_8php.html',1,'']]],
  ['admin_5futilizadores_2ephp_2',['admin_utilizadores.php',['../admin__utilizadores_8php.html',1,'']]],
  ['administração_20crud_3',['🛠️ Gestão e Administração (CRUD)',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['api_5fgraficos_2ephp_4',['api_graficos.php',['../api__graficos_8php.html',1,'']]],
  ['api_5flocais_2ephp_5',['api_locais.php',['../api__locais_8php.html',1,'']]],
  ['avaliações_20e_20social_6',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['avaliar_5flocal_2ephp_7',['avaliar_local.php',['../avaliar__local_8php.html',1,'']]],
  ['avançada_8',['🗺️ Mapa e Visualização Avançada',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
