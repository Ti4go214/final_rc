var searchData=
[
  ['_24categorias_0',['$categorias',['../admin__categorias_8php.html#a4a1ae44f0e8e6dcbb0723eb952ef4431',1,'admin_categorias.php']]],
  ['_24emaildest_1',['$emailDest',['../enviar__email_8php.html#abfb06d761cc989643999ad2191258118',1,'enviar_email.php']]],
  ['_24erro_2',['$erro',['../login_8php.html#acc3b8d7854869b897f454d2e75833bda',1,'login.php']]],
  ['_24id_3',['$id',['../eliminar__local_8php.html#a08a00586f6759822a046f42a83e5c690',1,'eliminar_local.php']]],
  ['_24locais_4',['$locais',['../api__locais_8php.html#af36a8f877aaa0e5717d1ebe0f1381850',1,'api_locais.php']]],
  ['_24msg_5',['$msg',['../admin__categorias_8php.html#a9e168f4152c267835864153c54449583',1,'admin_categorias.php']]],
  ['_24nomelocal_6',['$nomeLocal',['../enviar__email_8php.html#a2bef870ba72511a78fac9ec94c1efa29',1,'enviar_email.php']]],
  ['_24sql_7',['$sql',['../inserir__local_8php.html#a047170d6020a882807665812a27e2525',1,'$sql:&#160;inserir_local.php'],['../locais__lista_8php.html#ab7ca3eb602309cc8b08db007f3df5fcb',1,'$sql:&#160;locais_lista.php']]],
  ['_24sqltotallocais_8',['$sqlTotalLocais',['../api__graficos_8php.html#ada9a71d228ea506514e2376fbc152330',1,'api_graficos.php']]],
  ['_24st_9',['$st',['../inserir__local_8php.html#ad18f3ae11ee60977b262035d23094f86',1,'inserir_local.php']]],
  ['_24stmt_10',['$stmt',['../admin__categorias_8php.html#af27a9140d5f2658693e7fd107f716449',1,'$stmt:&#160;admin_categorias.php'],['../eliminar__local_8php.html#af27a9140d5f2658693e7fd107f716449',1,'$stmt:&#160;eliminar_local.php']]],
  ['_24sucesso_11',['$sucesso',['../registar_8php.html#a753c4666a955220ce7a5cb04ef8a2031',1,'registar.php']]],
  ['_24utilizadores_12',['$utilizadores',['../admin__utilizadores_8php.html#ae68481917f30522d3ca550f153178cdb',1,'admin_utilizadores.php']]]
];
