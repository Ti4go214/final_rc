var searchData=
[
  ['administração_20crud_0',['🛠️ Gestão e Administração (CRUD)',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['avaliações_20e_20social_1',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['avançada_2',['🗺️ Mapa e Visualização Avançada',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
