var searchData=
[
  ['e_20administração_20crud_0',['🛠️ Gestão e Administração (CRUD)',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['e_20filtros_1',['🔍 Pesquisa e Filtros',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['e_20geolocalização_2',['📍 GPS e Geolocalização',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['e_20social_3',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['e_20visualização_20avançada_4',['🗺️ Mapa e Visualização Avançada',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['eliminar_5flocal_2ephp_5',['eliminar_local.php',['../eliminar__local_8php.html',1,'']]],
  ['endif_6',['endif',['../login_8php.html#a8d1c73a077c6cd9caa0cd1f5fb18ceba',1,'login.php']]],
  ['enviar_5femail_2ephp_7',['enviar_email.php',['../enviar__email_8php.html',1,'']]],
  ['executar_20localmente_8',['💻 Instruções para Executar Localmente',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
