var searchData=
[
  ['if_0',['if',['../admin__dashboard__graficos_8php.html#a609147b8fc5c577a0abdb357387ad600',1,'if:&#160;admin_dashboard_graficos.php'],['../enviar__email_8php.html#a4a4d52370cb11e102017e83d799a23b5',1,'if:&#160;enviar_email.php'],['../index_8php.html#a446325495fcae4a3ed245b98123ebe59',1,'if:&#160;index.php']]],
  ['index_2ephp_1',['index.php',['../index_8php.html',1,'']]],
  ['inserir_5flocal_2ephp_2',['inserir_local.php',['../inserir__local_8php.html',1,'']]],
  ['instalação_3',['Passos de Instalação',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['instruções_20para_20executar_20localmente_4',['💻 Instruções para Executar Localmente',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['interativo_20🌍_5',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]]
];
