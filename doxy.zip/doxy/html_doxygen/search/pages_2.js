var searchData=
[
  ['de_20avaliações_20e_20social_0',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['de_20gestão_20geográfica_20interativo_20🌍_1',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]],
  ['de_20instalação_2',['Passos de Instalação',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['descrição_20do_20projeto_3',['📝 Descrição do Projeto',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['do_20projeto_4',['📝 Descrição do Projeto',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
