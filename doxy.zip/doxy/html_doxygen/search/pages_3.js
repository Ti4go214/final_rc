var searchData=
[
  ['e_20administração_20crud_0',['🛠️ Gestão e Administração (CRUD)',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['e_20filtros_1',['🔍 Pesquisa e Filtros',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['e_20geolocalização_2',['📍 GPS e Geolocalização',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['e_20social_3',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['e_20visualização_20avançada_4',['🗺️ Mapa e Visualização Avançada',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['executar_20localmente_5',['💻 Instruções para Executar Localmente',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
