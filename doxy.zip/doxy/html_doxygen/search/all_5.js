var searchData=
[
  ['filtros_0',['🔍 Pesquisa e Filtros',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['funcionalidades_20principais_1',['🚀 Funcionalidades Principais',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
