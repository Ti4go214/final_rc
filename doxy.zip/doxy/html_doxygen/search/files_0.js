var searchData=
[
  ['admin_5fcategorias_2ephp_0',['admin_categorias.php',['../admin__categorias_8php.html',1,'']]],
  ['admin_5fdashboard_5fgraficos_2ephp_1',['admin_dashboard_graficos.php',['../admin__dashboard__graficos_8php.html',1,'']]],
  ['admin_5futilizadores_2ephp_2',['admin_utilizadores.php',['../admin__utilizadores_8php.html',1,'']]],
  ['api_5fgraficos_2ephp_3',['api_graficos.php',['../api__graficos_8php.html',1,'']]],
  ['api_5flocais_2ephp_4',['api_locais.php',['../api__locais_8php.html',1,'']]],
  ['avaliar_5flocal_2ephp_5',['avaliar_local.php',['../avaliar__local_8php.html',1,'']]]
];
