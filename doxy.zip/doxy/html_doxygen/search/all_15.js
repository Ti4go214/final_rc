var searchData=
[
  ['🔍_20pesquisa_20e_20filtros_0',['🔍 Pesquisa e Filtros',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]]
];
