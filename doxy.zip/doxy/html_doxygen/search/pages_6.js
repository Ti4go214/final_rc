var searchData=
[
  ['instalação_0',['Passos de Instalação',['../md__r_e_a_d_m_e.html#autotoc_md11',1,'']]],
  ['instruções_20para_20executar_20localmente_1',['💻 Instruções para Executar Localmente',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]],
  ['interativo_20🌍_2',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]]
];
