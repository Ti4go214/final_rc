var searchData=
[
  ['sistema_20de_20avaliações_20e_20social_0',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['sistema_20de_20gestão_20geográfica_20interativo_20🌍_1',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]],
  ['smtpoptions_2',['SMTPOptions',['../enviar__email_8php.html#a7f443129df384681fe7089e04e04b313',1,'enviar_email.php']]],
  ['social_3',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]]
];
