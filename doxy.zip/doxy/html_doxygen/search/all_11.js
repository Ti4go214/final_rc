var searchData=
[
  ['🌍_0',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]]
];
