var searchData=
[
  ['⭐_20sistema_20de_20avaliações_20e_20social_0',['⭐ Sistema de Avaliações e Social',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]]
];
