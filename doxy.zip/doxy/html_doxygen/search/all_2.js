var searchData=
[
  ['config_5femail_2ephp_0',['config_email.php',['../config__email_8php.html',1,'']]],
  ['crud_1',['🛠️ Gestão e Administração (CRUD)',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
