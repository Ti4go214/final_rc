var searchData=
[
  ['registar_2ephp_0',['registar.php',['../registar_8php.html',1,'']]],
  ['requisitos_1',['Pré-requisitos',['../md__r_e_a_d_m_e.html#autotoc_md10',1,'']]]
];
