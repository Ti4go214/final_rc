var searchData=
[
  ['geodados_20sistema_20de_20gestão_20geográfica_20interativo_20🌍_0',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]],
  ['geográfica_20interativo_20🌍_1',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]],
  ['geolocalização_2',['📍 GPS e Geolocalização',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['gestão_20e_20administração_20crud_3',['🛠️ Gestão e Administração (CRUD)',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['gestão_20geográfica_20interativo_20🌍_4',['GeoDados - Sistema de Gestão Geográfica Interativo 🌍',['../md__r_e_a_d_m_e.html',1,'']]],
  ['gps_20e_20geolocalização_5',['📍 GPS e Geolocalização',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
