var api__locais_8php =
[
    [ "$locais", "api__locais_8php.html#af36a8f877aaa0e5717d1ebe0f1381850", null ]
];